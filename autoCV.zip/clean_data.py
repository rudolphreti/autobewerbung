import json
import re

def clean_company_strings(data):
    patterns_to_remove = [
        r'\(mwd\)',
        r'\(w/m/d\)',
        r'm/w/d',
        r'\(m/w/d\)',
        r'/in',
        r':in',
        r'\(f/m/d\)',
        r'\(w/m/\*\)',
        r'\(m/f/x\)',
        r'\(M/W\)',
        r'\(m/w/d\)'
    ]
    
    pattern = '|'.join(patterns_to_remove)
    print(f"Kombiniertes Suchmuster: {pattern}")
    
    for index, item in enumerate(data):
        print(f"\nVerarbeite Eintrag {index + 1}:")
        
        if 'company' in item:
            original_company = item['company']
            item['company'] = re.sub(pattern, '', item['company']).strip()
            print(f"  Company vorher: '{original_company}'")
            print(f"  Company nachher: '{item['company']}'")
            if original_company != item['company']:
                print("  Änderung in Company erkannt")
            else:
                print("  Keine Änderung in Company")
        
        if 'position' in item:
            original_position = item['position']
            item['position'] = re.sub(pattern, '', item['position']).strip()
            print(f"  Position vorher: '{original_position}'")
            print(f"  Position nachher: '{item['position']}'")
            if original_position != item['position']:
                print("  Änderung in Position erkannt")
            else:
                print("  Keine Änderung in Position")
    
    return data

# Daten aus der JSON-Datei lesen
print("Lese data.json...")
with open('data.json', 'r', encoding='utf-8') as file:
    data = json.load(file)
print(f"Anzahl der gelesenen Einträge: {len(data)}")

# Funktion aufrufen
print("\nStarte Bereinigung...")
cleaned_data = clean_company_strings(data)

# Bereinigte Daten zurück in die ursprüngliche JSON-Datei schreiben
print("\nSchreibe bereinigte Daten zurück in data.json...")
with open('data.json', 'w', encoding='utf-8') as file:
    json.dump(cleaned_data, file, ensure_ascii=False, indent=4)

print("Bereinigung abgeschlossen. Die Ergebnisse wurden in 'data.json' aktualisiert.")

# Überprüfung der Änderungen
print("\nÜberprüfe Änderungen:")
with open('data.json', 'r', encoding='utf-8') as file:
    final_data = json.load(file)

if final_data == cleaned_data:
    print("Die Daten wurden erfolgreich in der Datei aktualisiert.")
else:
    print("WARNUNG: Die Daten in der Datei stimmen nicht mit den bereinigten Daten überein!")

print("\nProzess abgeschlossen.")